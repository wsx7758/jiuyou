import Vue from 'vue';
import Vuex from 'vuex';
import main from '../main.js';

Vue.use(Vuex);
export default new Vuex.Store({
  state: {
    name:1
  },
  mutations: {
    getusername (state,name) {
    	console.log(this)
      state.name=name
      // this.$setToken('usname',name)
    }
  }
})