// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import axios from 'axios'
import router from './router/index.js'
import store from './store/index.js'
Vue.prototype.$axios=axios   //挂载axios（全部组件可用）
axios.interceptors.request.use(function (config) {//返回数据拦截
    // Do something before request is sent
    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });
Vue.config.productionTip = false;
Vue.prototype.$setToken = function (tokenName, tokenValue) {
    if (window.localStorage) {
      localStorage.setItem(tokenName, tokenValue);
    } else {
      alert('This browser does NOT support localStorage');
    }
};
Vue.prototype.$getToken = function (name) {
    var token = localStorage.getItem(name);
    if (token) {
      return token;
    } else {
      return '';
    }
  };
  Vue.prototype.$delToken = function (delName) {
    if (window.localStorage) {
      localStorage.removeItem(delName);
    } else {
      alert('This browser does NOT support localStorage');
    }
};

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
