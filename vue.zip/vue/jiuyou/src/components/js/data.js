const express=require('express');
const path=require('path');
const fs=require('fs');
const router=express.Router();
const url=require('url');
const mongoose=require('mongoose');
const mailer=require('./mailer.js');
const utli=require("./util.js");
const userModel=require('./userModel.js');
router.post('/home',(req,res)=>{
	fs.readFile(path.join(__dirname,'../../json/Json.json'),(err,data)=>{
	if(err){
		console.log(err)
		res.send({msg:'no ok',code:'-1'});
	}
	let list=JSON.parse(data)
	res.send({msg:'ok',code:'0',gamelist:list.data.list})
	// res.send('ok')
	// console.log(typeof(data))
})
})
router.post('/banner',(req,res)=>{
	fs.readFile(path.join(__dirname,'../../json/banner.json'),(err,data)=>{
	if(err){
		console.log(err)
		res.send({msg:'no ok',code:'-1'});
	}
	res.send(data)
	// res.send('ok')
	// console.log(typeof(data))
})
})
router.post('/shoot',(req,res)=>{
	let arr=[];
	fs.readFile(path.join(__dirname,'../../json/Json.json'),(err,data)=>{
	if(err){
		console.log(err)
		res.send({msg:'no ok',code:'-1'});
	}
	let list=JSON.parse(data)
	// res.send(list.data)
	// console.log(JSON.parse(data))
	for(var i in list.data.list){
		for(let j in list.data.list[i].gameTypes){
			if(list.data.list[i].gameTypes[j]=='射击'){
				arr.push(list.data.list[i])
			}
		}
	}
	res.send({msg:'ok',code:'0',gamelist:arr});
	// console.log(typeof(data))
})
})
router.post('/role',(req,res)=>{
	let arr=[];
	fs.readFile(path.join(__dirname,'../../json/Json.json'),(err,data)=>{
	if(err){
		console.log(err)
		res.send({msg:'no ok',code:'-1'});
	}
	let list=JSON.parse(data)
	// res.send(list.data)
	// console.log(JSON.parse(data))
	for(var i in list.data.list){
		for(let j in list.data.list[i].gameTypes){
			if(list.data.list[i].gameTypes[j]=='角色'){
				arr.push(list.data.list[i])
			}
		}
	}
	res.send({msg:'ok',code:'0',gamelist:arr});
})
})
router.get('/gamedeta',(req,res)=>{
	// console.log(encodeURI(req.url))
	// console.log(decodeURIComponent(req.query.name))
	// let name=encodeURI(req.url)
	let gamename=decodeURIComponent(req.query.name)
	let arr=[];
	fs.readFile(path.join(__dirname,'../../json/Json.json'),(err,data)=>{
	if(err){
		console.log(err)
		res.send({msg:'no ok',code:'-1'});
	}
	let list=JSON.parse(data)
	// res.send(list.data)
	// console.log(JSON.parse(data))
	for( let i in list.data.list ){
		if(list.data.list[i].gameName==gamename){
			arr.push(list.data.list[i])
			break;
		}
	}
	// console.log(gamename)
	res.send({msg:'ok',code:'0',gamelist:arr});
})
})

var arr='';
/**
 * @api {post} /user/login 登陆
 * @apiName login
 * @apiGroup User
 *
 * @apiParam {String} usname/email Users unique ID.
 * @apiParam {String} usps Users unique ID.
 *
 * @apiSuccess {String} err Firstname of the User.
 * @apiSuccess {String} msg  Lastname of the User.
 */

router.post('/login',(req,res)=>{
    let {usps,email}=req.body;
    userModel.find({email,usps})
    .then((data)=>{
        // console.log(data)
        if(data.length>=1){
            return res.send(utli.sendData(0,'登陆成功',data[0].usname));
        }
        res.send(utli.sendData(-1,'登陆失败',null));
    });
});
/**
 * @api {post} /user/reg 注册
 * @apiName reg
 * @apiGroup User
 *
 * @apiParam {String} usname Users unique ID.
 * @apiParam {String} email Users unique ID.
 * @apiParam {String} usps Users unique ID.
 * @apiParam {String} code Users unique ID.
 *
 * @apiSuccess {String} err Firstname of the User.
 * @apiSuccess {String} msg  Lastname of the User.
 */
router.post('/reg',(req,res)=>{
    let {usps,code,email}=req.body;
    // console.log({usname,usps,email})
    if(arr!=code){return res.send(utli.sendData(-1,'验证码错误',null))}
    userModel.insertMany({email,usps})
    .then((data)=>{
        res.send(utli.sendData(0,'注册成功',null))})
    .catch((err)=>{
        console.log(err);
        res.send(utli.sendData(-1,'注册失败',null))});
    
});
/**
 * @api {post} /user/getcode 获取验证码
 * @apiName getcode
 * @apiGroup User
 *
 * @apiParam {String} email Users unique ID.
 *
 * @apiSuccess {String} err 错误码.
 * @apiSuccess {String} msg  信息.
 */
router.post('/getcode',(req,res)=>{
    let {email}=req.body;
    let x=(parseInt(Math.random()*10000)).toString();
    mailer.sendmail(email,x)
    .then((resolve)=>{
        arr=x;
        // console.log(typeof(arr),arr)
        res.send(utli.sendData(0,'已发送',null))})
    .catch((err)=>{
        // console.log(err)
        res.send(utli.sendData(-1,'发送失败',null))})
});
/**
 * @api {post} /user/repeat 验证邮箱
 * @apiName email
 * @apiGroup User
 *
 * @apiParam {String} email Users unique ID.
 *
 * @apiSuccess {String} err 错误码.
 * @apiSuccess {String} msg  信息.
 */
router.post('/repeat',(req,res)=>{
    let {email}=req.body;
    userModel.find({'email':email})
    .then((data)=>{
        if(data.length>=1){return res.send(utli.sendData(-1,'邮箱以注册',null))}
            else{return res.send(utli.sendData(0,'邮箱可以注册',null))}
    })
    .catch((err)=>{
           res.send(utli.sendData(-1,'出错啦',null)) 
    })
})



module.exports=router;
  