const mongoose=require('mongoose');

let Schema=mongoose.Schema;
let userifm=new Schema({
    usps:{type:String,required:true},
    email:{type:String,required:true}
});
let usermodel=mongoose.model('user',userifm);
                        //    表名   Schema
module.exports=usermodel;//抛出
