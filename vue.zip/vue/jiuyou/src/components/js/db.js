const mongoose=require('mongoose');
//链接数据库
mongoose.connect('mongodb://localhost:27017/user',{ useNewUrlParser: true });
// mongoose.connect('mongodb://localhost:27017/carlist',{ useNewUrlParser: true });
//监听
let db=mongoose.connection;//数据库对象
db.on('error',()=>{console.log('connection error')});
db.on('open',()=>{console.log('链接成功')});
db.on('disconnected',()=>{console.log('链接断开')});


// let Schema=mongoose.Schema;
// let userifm=new Schema({
//     usname:{type:String,required:true},
//     usps:{type:String,required:true}
// });
// let usermodel=mongoose.model('user',userifm);
//                         //    表名   Schema
// // usermodel.insertMany({usname:'qwe',usps:'123'})
// usermodel.find()
// .then((data)=>{
//     console.log(data)
// })
// .catch((err)=>{
//     console.log(err)
// })



