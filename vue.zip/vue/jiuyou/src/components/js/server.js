const express=require('express');
const app=express();
const datalist=require('./data.js');
const bodyParser=require('body-parser')
const db=require('./db.js');
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use('/api/game',datalist)






app.listen(3000,()=>{
	console.log('服务器开启')
})