<template>
	<div id="head">
		<!-- {{this.$store.state.count}} -->
		<div id="logo">
			<a href="#"><img src="http://i.9game.cn/public/web/img/ng_navigationbar_logo@2x.32e2887a.png"></a>
			<i class="fa fa-bars" @click="open"></i>
		</div>
		<transition
		enter-active-class = "animated  fadeInDownBig"
         leave-active-class = "animated  fadeOutUpBig">
			<div id="mask"  v-if="show" :class="show?'mask':''">
				<div id="con">
					<div id="shut" @click='open'>
						<img class="cha" src="/static/cha.png">
					</div>
					<div id="uslogo" :class="imgsrc?'bgimg':'bgimgb'">
						<!-- <img src="/static/uslogo.png"> -->
					</div>
					<router-link  :id="item.name=='登陆/注册'?'r-l':'tablist'" :to='item.to' tag='div' v-for='(item,index) in navlist' :key="index">{{item.name}}</router-link>
					<!-- <div id='r-l'>登陆/注册<div>
					<router-link to='/' tag='div' id='tablist'>首页</router-link>
					<div id='tablist'>我的游戏</div>
					<router-link to='/' tag='div' id='tablist'>下载九游App</router-link>
					<router-link to='/' tag='div' id='tablist'>参与游戏测试</router-link> -->
					<div @click='delstorage' v-if='showb' id="tablist">退出登陆</div>
				</div>
		</div>

		</transition>
	</div>

</template>
<script type="text/javascript">
	import Banner from './Banner.vue'
	export default {
		name:'Header',
		data(){
			return {
				navlist:[{name:'',to:'/login'},{name:'首页',to:'/'},{name:'我的游戏',to:'/mygame'},{name:'下载九游App',to:'/download'},{name:'参与游戏测试',to:'/wechat'}],
				show:false,
				showb:false,
				imgsrc:false
			}
		},
		methods:{
			open(){
				this.show=!this.show
				console.log(this.$router)
			},
			delstorage(){
				this.$delToken('usname')
				// window.location.href='http://localhost:8080'
				this.$router.push('/')
				this.show=!this.show
			}
		},
		beforeMount(){
			// console.log(this.$delToken)
			if(!this.$getToken('usname')){
				this.navlist[0].name='登陆/注册'
			}else{
				this.navlist[0].name='欢迎你'+this.$getToken('usname')
				this.showb=true
				this.imgsrc=true
			}
			
		},
		components: {
			
 		},
 		created(){
 			// console.log(this.$store.state.count)s
 		}
	}
</script>
<style type="text/css" scoped lang="less">
@import '../../styles/main.less';
.bgimg{
	.b-r(40);
	.bgimg("http://sh.image.uc.cn/s/y9c/g/myspace_server/system/20170726/1501034927190986855_thumb.JPG");
}
.bgimgb{
	.bgimg("/static/uslogo.png");
}
.cha{
	.h(26);
	.w(26);
}
	#head{
		position: fixed;
		.t(0);
		.l(0);
		z-index: 11111;
		background: white;
	}

	
	#mask{
		transition: height .25s linear;
		z-index: 11111;
		.w(375);
		// .h(0);
		position: fixed;
		.t(0);
		.l(0);

		background: rgba(0,0,0,.5);
		#con{
			display: flex;
			flex-direction: column; 
			justify-content: center;
			align-items: center;
			z-index: 11;
			position: relative;
			.w(375);
			// .h(372);
			background: white;
			#tablist{
				.w(335);
				.h(56);
				.font(18);
				text-align: center;
				.l-h(56);
				border-bottom: 1px solid #ddd;
			}
			#r-l{
				// .h();
				.font(16);
			}
			#uslogo{
				.m(25,0,0,0); 
				.w(80);
				.h(80);
				
				.bgsize(80,80);
			}
			#shut{
				position: absolute;
				.r(5);
				.t(5);
				.font(28);
				.h(26);
				.w(26);
			}
		}
		
	}
	
	#logo{
		position: relative;
		.h(44);
		.w(375);
		// .l-h(44);
		text-align: center;
		img{
			.h(25);
			.w(60);
		}
		i{
			.font(28);
			float: right;
			position: absolute;
			.r(15);
			.b(8);
		}

	}
	.mask{.h(667);}
</style>