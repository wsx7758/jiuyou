<template>
	<div id="banner">
		<Load/>
		<div class="swiper-container">
		    <div class="swiper-wrapper">
		        <div class="swiper-slide" v-for="(item,index) in list" :key="index">
		        	<img :src="item">
		        </div>
		    </div>
		</div>
	</div>
</template>
<script type="text/javascript">
	import Swiper from 'swiper';
	import Vue from 'vue';
	import Load from './Load.vue';
	export default{
		name:'Banner',
		components:{
			Load
		},
		data(){
			return {
				list:[]
			}
		},
		methods:{
			getaxios(){
				this.$axios.post('/api/api/game/banner')
				.then((res)=>{
					// console.log(res.data.list)
					this.list=res.data.list
					// console.log(this.list)
					Vue.nextTick(()=>{
						var mySwiper = new Swiper ('.swiper-container', {
							loop: true, // 循环模式选项
							autoplay:{
								disableOnInteraction: false,
								delay: 2000
							}
							})
					})
				})
				.catch((err)=>{
					console.log(err)
				})
			}
		},
		mounted(){
			        
		},
		created(){
			this.getaxios()
		},
		destroyed(){
			delete this.mySwiper
		}
		
	}
</script>
<style type="text/css" scoped lang="less">
@import '../../styles/main.less';
@import '../../../node_modules/swiper/dist/css/swiper.css';
#banner{
	.m(86,0,0,0) 
}
.swiper-slide{
	.w(375);
	.h(200);
	img{
		width: 100%;height: 100%;
	}
}

	
</style>