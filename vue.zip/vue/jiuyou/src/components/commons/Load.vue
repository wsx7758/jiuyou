<template>
	<div id="load" v-if='show'>
		<div><img src="/static/LOGO.gif"></div>
	</div>
</template>
<script type="text/javascript">
	export default{
		name:'Load',
		data(){
			return {
				show:false
			}
		},
		methods:{
			handleScroll () {
			  var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
			  // console.log(scrollTop)
			  if(scrollTop==0){
			  	this.show=true
			  	setTimeout(()=>{
			  		this.show=false
			  	},2000)
			  }
			}
		},
		mounted(){
			 window.addEventListener('scroll', this.handleScroll)
		}

	}
</script>
<style type="text/css" lang="less" scoped>
	@import '../../styles/common/mixin.less';
	#load{
		
		.h(60);
		.l-h(60);
		text-align: center;
		img{
			.w(35);
			.h(35);
		}
	}
</style>