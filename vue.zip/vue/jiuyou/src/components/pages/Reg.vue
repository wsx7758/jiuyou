<template>
	<div id="reg">
		<div id="top">
			<p onclick="javascript:history.back(-1);"><i class="fa fa-chevron-left"></i></p>
			快速注册
		</div>
		<div id="user">
			<div><span class="fa fa-envelope-o"></span><input @blur='setemail' type="text" id="usname" class="inp" placeholder="请输入邮箱" v-model='usname'></div>
			<span id="sp" :class="code!=0?'red':'green'">{{msg}}</span>
			<div><span class="fa fa-user-o"></span><input type="password" id="usps" class="inp" placeholder="请输入密码" v-model="usps"></div>
			<div><input placeholder="请输入验证码" type="text"  class="yanz" v-model='yzm'><button class="but" @click='getcode'>获取验证码</button></div>
			<button class="reg" @click='regnow'>注册</button>
		</div>
		<router-link to='/login' id="tab">
			<i>已有账号？点击登录</i>
		</router-link>
		
	</div>
</template>
<script type="text/javascript">
	export default {
		name:'Reg',
		data(){
			return{
				usname:'',
				usps:'',
				yzm:'',
				msg:'',
				code:'',
				color:{color:'red'},
				colorb:{color:'green'}
			}
			
		},
		updated(){
			// this.$store.commit('getusername',100)
			// console.log(this.$store.state.name)
			// console.log(this.$getToken)
		},
		methods:{
			regnow(){
				this.$axios.post('/api/api/game/reg',{
					usps:this.usps,
					code:this.yzm,
					email:this.usname
				})
				.then((data)=>{
					// console.log(data.data.msg)
					alert(data.data.msg)
					if(data.data.err==0){
						// this.$store.commit('getusername',100)
						this.$setToken('usname',this.usname)
						// window.location.href='http://localhost:8080/#/login'
						this.$router.push('/login')
					}
				})
				.catch((err)=>{
					console.log(err)
				})
			},
			getcode(){
					this.$axios.post('/api/api/game/getcode',{
						email:this.usname
					})
					.then((data)=>{
						// console.log(data.data.msg)
						alert(data.data.msg)
					})
					.catch((err)=>{
						console.log(err)
					})
				
				
			},
			setemail(){
				if(/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/.test(this.usname)){
					this.$axios.post('/api/api/game/repeat',{
						email:this.usname
					})
					.then((data)=>{
						this.msg=data.data.msg
						this.code=data.data.err
						// console.log(this.code)
					})
					.catch((err)=>{
						console.log(err)
					})
				}else{
					this.msg='无效的邮箱'
					this.code=-1
				}
				
			}
		}
	}
</script>
<style type="text/css" lang='less' scoped>
	@import '../../styles/common/mixin.less';
	#sp{
		.font(12);
	}
	.red{
		color: red;
	}
	.green{
		color: green;
	}
	#tab{
		color: blue;
		.font(16);
		.m(10,0,0,5);
	}
	#reg{
		background-color: #fff;
		.w(375);
		.h(667);
		background-repeat: no-repeat;
    	background-size: 100% 80px;
		background-image: -webkit-linear-gradient(-90deg,rgba(44,153,255,.10196) 0,rgba(44,153,255,0) 100%);
		-webkit-tap-highlight-color: transparent;
		}
		#user{
			.m(20,0,0,0);
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			.reg{
				.w(336);
				.h(48.5);
				.m(10,0,0,0);
				background: #2c99ff;
				border: none;
				outline: none;
			}
			div{
				.font(30);
				.l-h(40);
				border-bottom: 1px solid #ddd;
				.yanz{
					.w(270);
					.h(40);
					border: none;
					.p(0,0,0,20);
					outline: none;
				}
				.but{
					.h(40);
					background: #fff;
					border: none;
					outline: none;
				}
				.inp{
					.w(300);
					.h(40);
					border: none;
					.p(0,0,0,20);
					outline: none;
				}
			}
		}
		#top{
			.w(375);
			.h(44);
			position: relative;
			text-align: center;
			.l-h(44);
		    .m(0,0,25,0);
		    color: #333;
		    .font(22);
		    .p(0,45,0,45);
			p{
				position: absolute;
				.t(1);
			    .l(10);
			    .w(25);
			    .h(25);
			    color: ;
			}
			
		}
	

</style>