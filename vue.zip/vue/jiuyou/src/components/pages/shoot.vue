<template>

	<div id="body">
		<Header/>
		<div id="nav">
			<router-link tag='div' :to='item.to' :class="pick==item.to?'hl':''"  v-for='(item,index) in navlist' :key='index'>{{item.name}}</router-link>
		</div>
		
		<ul v-infinite-scroll="loadMore"
			infinite-scroll-disabled="loading"
			infinite-scroll-distance="10">
			<Load/>
			<li v-for='(item,index) in list' :key='index' @click='getname(item.gameName)'>
				<div class="top">
					<a class="jylogo"><img src="http://i.9game.cn/public/web/img/ng_pic_default_gameicon@2x.28066e17.png"></a>
					<a class="date">111发布</a>
					<a class="nowtitle">预约</a>
				</div>
				<img :src="item.bannerImage" class="bannerimg">
				<!-- {{index}} -->
				<div class="bom">
					<span class="gameName">{{item.gameName}}</span>
					<span :style="index%2==0?{background:bgcolor}:{background:bgcolor2}" class="gameType" v-for="(val,index) in item.gameTypes" :key='index'>{{val}} </span>
				</div>
			</li>
		</ul>
	</div>
</template>
<script type="text/javascript">
	import { Toast , InfiniteScroll } from 'mint-ui';
	import {setCookie} from '../js/cookie.js';
	import Vue from 'vue';
	Vue.use(InfiniteScroll);
	// import { InfiniteScroll } from 'mint-ui';
	import Header from '../commons/Header.vue';
	import Load from '../commons/Load.vue';
	export default{
		name:'Body',
		components:{
			Header,
			Load
		},
		data(){
			return {
				pick:"/shoot",
				list:[],
				bgcolor:'skyblue',
				bgcolor2:'#0bc8a6',
				navlist:[{name:"推荐",to:"/"},{name:"射击",to:"/shoot"},{name:"角色",to:"/role"}],
				start:0,
				end:5
			}
		},
		methods:{
			loadMore(){
				console.log(this.start)
				console.log(this.end)
				this.ajax()
			},
			getname(name){
				setCookie('name',name)
				// window.location.href='http://localhost:8080/#/detalls'
				this.$router.push('/detalls')
			},
			ajax(){
				this.toast=Toast({
					 	message: 'loading',
					  	iconClass: 'fa fa-spinner fa-spin'
					});
				this.$axios.post('/api/api/game/shoot')
				.then((res)=>{
					this.list=this.list.concat(res.data.gamelist.slice(this.start,this.end))
					// this.list=res.data.data.list
					console.log(res.data.gamelist.slice(this.start,this.end))
					console.log('/api/api/game'+this.pick)
					this.toast.close();
					this.start+=5;
					this.end+=5;
					console.log(this.list)
				})
				.catch((err)=>{
					this.toast.close();
					console.log(err)
				})
			}
		},
		created(){

		},
		mounted(){

		},
		destoryed(){

		}
	}
</script>
<style type="text/css" lang="less" scoped>
@import '../../styles/common/mixin.less';
#body{
	// .m(44,0,0,0);
	overflow:auto;
	-webkit-overflow-scrolling: touch;
	#nav{
		z-index: 99;
		background: white;
		position: fixed;
		.t(43);
		.l(0);
		display: flex;
		text-align: center;
		border-bottom: 2px solid #ddd;
		.l-h(40);
		div{
			.w(125);
			.h(40);
			.font(16);

		}
		.hl{
			color: red;
		}

	}
	ul{
		display: flex;
		justify-content: space-between;
		flex-direction: column; 
		align-items: center;
		.m(84,0,0,0);
		li{
			list-style: none;
			.p(15,0,0,0);
			.w(375);
			.h(312);
			text-align: center;
			.bom{
				overflow: hidden;
				.m(5,0,0,0);
				.p(0,0,15,10);
				display: flex;
				align-items: center;
				.gameName{
					.font(18);
					font-weight: 700;
				}
				.gameType{
					display: block;
					.w(44);
					.h(20);
					.font(12);
					.l-h(20);
					.bgcolor(red);
					.p(0,10,0,10);
					.m(0,0,0,10);
					.color(#fff);
					transform: skew(-30deg);
				}
			}
			.top{
				.p(0,10,0,10);
				display: flex;
				align-items: center;
				.jylogo{
					.w(40);
					.h(40);
					img{
						width: 100%;
						height: 100%;
						border-radius: 50%;
					}
				}
				.date{
					.m(7,0,0,10);
					color: #999;
				    font-size: .24rem;
				}
				.nowtitle{
					position: absolute;
					.r(10);
					.font(15);
					.w(70);
					.h(32);
					.b-r(20);
					background: #0bc8a6;
					.l-h(32);
					.color(#fff); 
				}
			}
		}
	}
	.bannerimg{
		.m(10,0,0,0);
		.w(355);
		.h(200);
	}
}
	
</style>