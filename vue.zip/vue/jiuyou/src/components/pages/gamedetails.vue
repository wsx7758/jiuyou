<template>
	<div id="details">
		<Header/>
		<div id="banner">
		<Load/>
			<img :src="list.bannerImage">
		</div>
		<div id="gamename">
			{{list.gameName}}
		</div>
		<div id="leixing">
			<span v-for='(item,ind) in list.gameTypes' :key='ind'>{{item}}</span>
		</div>
		<div id="conbox">
				<div id="logo">
					<img class="imga" src="http://i.9game.cn/public/web/img/ng_pic_default_gameicon@2x.28066e17.png">
					<span>说</span>
					<img class="imgb" src="/static/111.png">
				</div>
				<div id="content">{{list.recommendWord}}</div>
			
		</div>
		<div id="tese"><b>游戏特色</b></div>
		<div id="jiesao">
			<ul id="ul" @click="pick">
				<li v-for='(item,ind) in list.gameScreenshots' :key='ind'><img :src="item">
					
				</li>
				<!-- <li><img src="http://image.9game.cn/s/y9v/g/2018/10/bd47b777ad7c9a1.jpg"></li>
				<li><img src="http://image.9game.cn/s/y9v/g/2018/10/bd47b777ad7c9a1.jpg"></li>
				<li><img src="http://image.9game.cn/s/y9v/g/2018/10/bd47b777ad7c9a1.jpg"></li> -->
			</ul>
			
			<div>
				请求数据无该字段，所以自定义
			</div>
		</div>
		<div id="tese"><b>测试信息</b></div>
		<div id="tese">QQ群：123456</div>
		<div id="footer">
			<div id="bgi">
				<div>预约</div>
			</div>
			<div id="foot">
				<h3>体验新游，做游戏策划</h3>
				<p>参与游戏测试，与开发者交流</p>
				<a href="#">区App Store 下载九游app></a>
			</div>
		</div>
		<!-- <div > -->
		<div id="div" v-if='show' @click="pick">
			<div class="swiper-container">
			  <div class="swiper-wrapper">
			    <div class="swiper-slide" v-for='(item,ind) in list.gameScreenshots' :key='ind'><img :src="item"></div>
			  </div>
			</div>
		</div>
		<!-- </div> -->
	</div>
</template>
<script type="text/javascript">
	import Swiper from 'swiper';
	import Load from '../commons/Load.vue';
	import Vue from 'vue';
	import Header from '../commons/Header.vue'
	import {getCookie} from '../js/cookie.js'
	export default{
		name:'Dtails',
		components:{
			Header,
			Load
		},
		methods:{
			pick(){
				this.show=!this.show
			}
		},
		data(){
			return {
				list:{},
				show:false
			}
		},
		created(){
			// console.log(getCookie('name'))
			this.$axios.get('/api/api/game/gamedeta',{params:{
				name:getCookie('name')
			}})
			.then((res)=>{
				this.list=res.data.gamelist[0]
				// console.log(this.list)
				Vue.nextTick(()=>{
					var mySwiper = new Swiper ('.swiper-container', {
						// loop: true, // 循环模式选项
						// autoplay:{
						// 	disableOnInteraction: false,
						// 	delay: 2000
						// }
						})
				})
			})
			.catch((err)=>{
				console.log(err)
			})
		},
		mounted(){
		// 	 var mySwiper = new Swiper('.swiper-container', {
		// 				autoplay: true,//可选选项，自动滑动
		// 			})       
		}
	}
</script>
<style type="text/css" lang="less" scoped>
	@import '../../styles/main.less';
	@import '../../../node_modules/swiper/dist/css/swiper.css';
	#div{
		position: fixed;
		overflow: auto;
		.l(0);
		.t(0);
		.w(375);
		.h(667);
		background: rgba(0, 0, 0, .9);
		z-index: 99999;
		.m(0,0,0,0);
		// .op(0.3);
		display: flex;
		justify-content: center;
		align-items: center;
		div{
			img{
			// width: 100%;
			.w(375);
			.h(570);
			z-index: 999999;
			}
		}
		
	}

	#footer{
		.w(375);
		background: #fff;
		display: flex;
		// flex-direction: column;
		justify-content: center;
		align-items: center;
		#bgi{
			position: fixed;
			display: flex;
			justify-content: center;
			align-items: center;
			.w(375);
			.b(0);
			.l(0);
			background: white;
			div{
				.w(355);
				.h(40);
				.b-r(20);
				background: skyblue;
				text-align: center;
				.l-h(40);
				.font(18);
				color: #fff;
			}
		}
		#foot{
			.m(0,0,81,0);
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			align-items: center;
			text-align: center;
			h3{
				.m(30,0,0,0);
				.font(25);
			}
			p{
				.font(18);
			}
			a{
				.font(14);
				    color: #f60;
			}
		}
	}
	#jiesao{
		.w(365);
		// .h(249);
		.m(15,0,0,0);
		#ul::-webkit-scrollbar {
		        display: none;
		    }
		ul{
			display: flex;
			overflow: auto;
			li{
				list-style: none;
				// float: left;
				.m(0,10,0,0);
				.w(210);
				.h(140);
				
				img{
					.w(210);
					.h(140);
				}
			}
		}
		div{
			.m(10,0,0,0);
			.font(14);
		}
	}
	
	#details{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	#tese{
		.w(365);
		.font(17);
		.m(8,0,0,0);
	}
	#banner{
		.m(44,0,0,0);
		img{
			.w(375);
			.h(210);
		}
	}
	#gamename{
		.w(375);
		.h(40);
		.font(25);
		font-weight: 700;
		text-align: center;
		.l-h(40);
	}
	#leixing{
		.w(375);
		text-align: center;
		display: flex;
		justify-content: center;
		color: #fff;
		span{
			display:block;
			transform: skew(-20deg);
			background: #0bc8a6;
			.font(10);
			.w(36);
			.h(16);
			text-align: center;
		}

	}
	#conbox{
		.w(365);
		// .h(230);
		.m(20,0,0,0);
		.p(15,15,15,15);
		background: #f6f6f6;
		border-radius: 5px; 
		#content{
			.p(10,0,0,0);
			.font(14);
		}
		#logo{
			display: flex;
			align-items: center;
			color: #b5b5b5;
			.font(10);
			.imga{
				.w(25);
				.h(25);
				.m(0,10,0,0);
			}
			.imgb{
				.w(20);
				.h(20);
				.m(0,0,0,270);
			}
		}
	}
</style>