<template>
	<div id="mygame">
		<Header/>
		<div id="top">
			<div id="uslogo"></div>
		</div>
		<div id="usname">九游玩家{{usname}}</div>
		<div id="fgx"></div>
		<div id="wanguo">
			<p>玩过</p>
			<div id="cona">
				<img src="http://i.9game.cn/public/web/img/ng_list_blank_icon_plane@2x.84e830a6.png">
				<p>玩过的游戏都在这里哦</p>
			</div>
		</div>
		<div id="fgx"></div>
		<div id="wanguo">
			<p>评论</p>
			<div id="cona">
				<img src="http://i.9game.cn/public/web/img/ng_list_blank_icon_plane@2x.84e830a6.png">
				<p>所有评论都在这里哦</p>
			</div>
		</div>
	</div>
</template>
<script type="text/javascript">
	import Header from '../commons/Header.vue'
	import router from 'vue-router';
	export default {
		name:'Mygame',
		components:{
			Header
		},
		data(){
			return {
				usname:''
			}
		},
		beforeMount(){
			if(!this.$getToken('usname')){
				var rel=confirm('请先登录')
				if(rel){
					// window.location.href='http://localhost:8080/#/login';
					// router.push('/login')
					this.$router.push('/login')
				}else{
					window.history.go(-1);
				}
				
			}
			this.usname=this.$getToken('usname')
		}
	}
</script>
<style type="text/css" lang="less" scoped>
@import '../../styles/main.less';
#fgx{
	background-color: #ebebeb;
	.w(375);
	.h(5);
}
#wanguo{
	min-height: 190px;
	.w(375);
	.p(0,10,0,10);
	.m(5,0,0,0);
	// background: red;
	p{
		.font(14);
		.p(15,0,15,0);
	}
	#cona{
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		color: #b5b5b5; 
		img{
			.w(60);
			.h(60);
		}
	}
}
#usname{
	.m(40,0,0,0);
	.font(17);
	text-align: center;
}
#top{
	position: relative;
	.w(375);
	.h(180);
	.m(44,0,0,0);
	background-color: #ebebeb;
	#uslogo{
		.l(144.5);
		.b(-43);
		position: absolute;
		border: .06rem solid #fff;
    	border-radius: 1.6rem;
		background: url('http://sh.image.uc.cn/s/y9c/g/myspace_server/system/20170726/1501034927190986855_thumb.JPG');
		.w(86);
		.h(86);
		background-size: cover;
    	background-position: 50%;
	}
}

</style>