<template>
	<div id="reg">
		<div id="top">
			<p onclick="javascript:history.back(-1);"><i class="fa fa-chevron-left"></i></p>
			快速登陆
		</div>
		<div id="user">
			<div><span class="fa fa-envelope-o"></span><input v-model='usname' type="text" id="usname" class="inp" placeholder="请输入邮箱"></div>
			<div><span class="fa fa-user-o"></span><input v-model='usps' type="password" id="usps" class="inp" placeholder="请输入密码"></div>
			<button @click='loginnow' class="reg">登录</button>
		</div>
		<router-link to='/reg' id="tab">
			<i>没有账号？点击注册</i>
		</router-link>
	</div>
</template>
<script type="text/javascript">
	export default {
		name:'Reg',
		data(){
			return {
				usname:'',
				usps:''
			}
		},
		methods:{
			loginnow(){
				this.$axios.post('/api/api/game/login',{
					email:this.usname,
					usps:this.usps
				})
				.then((res)=>{
					console.log(res)
					alert(res.data.msg)
					if(res.data.err==0){
						this.$setToken('usname',this.usname)
						// window.location.href='http://localhost:8080#/'
						this.$router.push('/mygame')
					}
				})
				.catch((err)=>{
					console.log(err)
				})
			}
		},
		beforeCreate(){

		}
	}
</script>
<style type="text/css" lang='less' scoped>
	@import '../../styles/common/mixin.less';
	#tab{
		color: blue;
		.font(16);
		.m(10,0,0,5);
	}
	#reg{
		background-color: #fff;
		.w(375);
		.h(667);
		background-repeat: no-repeat;
    	background-size: 100% 80px;
		background-image: -webkit-linear-gradient(-90deg,rgba(44,153,255,.10196) 0,rgba(44,153,255,0) 100%);
		-webkit-tap-highlight-color: transparent;
		}
		#user{
			.m(20,0,0,0);
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			.reg{
				.w(336);
				.h(48.5);
				.m(10,0,0,0);
				background: #2c99ff;
				border: none;
				outline: none;
			}
			div{
				.font(30);
				.l-h(40);
				border-bottom: 1px solid #ddd;
				.yanz{
					.w(270);
					.h(40);
					border: none;
					.p(0,0,0,20);
					outline: none;
				}
				.but{
					.h(40);
					background: #fff;
					border: none;
					outline: none;
				}
				.inp{
					.w(300);
					.h(40);
					border: none;
					.p(0,0,0,20);
					outline: none;
				}
			}
		}
		#top{
			.w(375);
			.h(44);
			position: relative;
			text-align: center;
			.l-h(44);
		    .m(0,0,25,0);
		    color: #333;
		    .font(22);
		    .p(0,45,0,45);
			p{
				position: absolute;
				.t(1);
			    .l(10);
			    .w(25);
			    .h(25);
			    color: ;
			}
			
		}
	

</style>