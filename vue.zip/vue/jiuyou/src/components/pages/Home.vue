<template>
	<div id="home">
		<Header/>
		<Banner/>
		<Body/>
	</div>
</template>
<script type="text/javascript">
import Header from '../commons/Header.vue'	
import Banner from '../commons/Banner.vue'
import Body from '../commons/body.vue'

	export default{
		name:'Home',
		components: {
      		Header,
      		Banner,
      		Body
 		},
 		methods:{
			 handleScroll() {
		        console.log(document.getElementById('home').scrollTop)
		    }
		},
 		mounted(){
			document.getElementById('home').addEventListener('scroll', this.handleScroll)
		},
	}
</script>
<style type="text/css" lang="less" scoped>
@import '../../styles/main.less';
	#home{
	// color: @color;
	// .color(yellow);
	// .bgcolor(red);
	}
</style>