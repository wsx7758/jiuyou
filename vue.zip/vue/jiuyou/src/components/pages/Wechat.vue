<template>
	<div id="wechat">
		<Header/>
		<div id="con">
			<h4>第一时间参加游戏测试</h4>
			<p><span>01. </span>  关注九游公众号：九游ios</p>
			<div id="ewm">
				<img src="http://i.9game.cn/public/web/img/qr-code.1ee4558f.jpg">
			</div>
			<div id="qqq">02.  加入官方qq群</div>
			<div id="qqh"><span>9966293</span></div>
		</div>
	</div>
</template>
<script type="text/javascript">
	import Header from '../commons/Header.vue';
	export default {
		name:'Wechat',
		components:{
			Header
		}
	}
</script>
<style type="text/css" scoped lang="less">
	@import '../../styles/main.less';
	#con{
		.m(44,0,0,0);
		display: flex;
		flex-direction: column; 
		justify-content: center;
		align-items: center;
		.font(16);
		#qqh{
			.m(15,0,0,0);
			background: url('http://i.9game.cn/public/web/img/step-2.89691457.jpg');
			.w(192);
			.h(58.5);
			background-size: cover;
    		background-position: 50%;
    		text-align: center;
    		position: relative;
    		span{
    			position: absolute;
			    .l(83);
			    .t(24);
			    font-size: .36rem;
			    font-weight: 700;
			    color: #000;
    		}
		}
		#qqq{
			.m(50,0,0,0);
		}
		
		h4{
			.m(48,0,0,0);
			.font(25);
		}
		p{
			.m(38,0,0,0);
			
		}
		#ewm{
			.m(30,0,0,0);
			.w(280.5);
			.h(173.5);
			img{
				width: 100%;
				height: 100%;
			}
		}
	}
</style>