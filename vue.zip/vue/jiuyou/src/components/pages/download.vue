<template>
	<div id="download">
		<Header/>
		<transition
		enter-active-class = "animated  zoomIn"
         leave-active-class = "animated  fadeOutUpBig">
         <div class="download" v-if='show'>
		<div id="con">
			<div class="div1">
				<div class="bgimg  img1"></div>
				<span>终结者</span>
			</div>
			<div class="div2">
				<div class="bgimg img2"></div>
				<span>终结者2</span>
			</div>
			<div class="div3">
				<div class="bgimg img3"></div>
				<span>终结者3</span>
			</div>
			<div class="div4">
				<div class="bgimg img4"></div>
				<span>终结者4</span>
			</div>
			<div class="div5">
				<div class="bgimg img5"></div>
				<span>终结者5</span>
			</div>
			<div class="div6">
				<div class="bgimg img6"></div>
				<span>终结者6</span>
			</div>
		</div>
	
		<div id="jylogo">
			<img src="http://i.9game.cn/public/web/img/appicon.035789fb.png">
			<p>九游iOS APP</p>
		</div>
		<div id="jh">聚合你最关心的游戏内容</div>
		<p class='p1'>新游测试、电竞赛事、攻略、咨询、问答</p>
		<a href="#" class="dowl">前往App Store下载</a>
		</div>
		</transition>
	</div>
</template>
<script type="text/javascript">
	import Header from '../commons/Header.vue'
	export default {
		name:'Download',
		components:{
			Header
		},
		data(){
			return {
				show:false
			}
		},
		methods:{
			showtime(){
				setTimeout(()=>{
					this.show=true
				},100)
			}
		},
		mounted(){
			this.showtime()
		}
	}
</script>
<style lang="less" type="text/css" scoped>
	@import '../../styles/main.less';
	.dowl{
		display: block;
		.w(230);
		.h(48);
		.b-r(24);
		.font(15);
		background: #ff9700;
		text-align: center;
		.l-h(48);
		.m(12,0,0,0);
	}
	.p1{
		.font(12);
		color: #7b7f88;
	}
	#jh{
		.font(20);
		font-weight: 700;
		.m(20,0,0,0);
	}
	#jylogo{
		.m(15,0,0,0);
		display: flex;
		justify-content: center;
		align-items: center;
		p{
			.m(0,0,0,15);
			.font(30);
			font-weight: 700;
		}
		img{
			.w(30);
			.h(30);
		}
	}

	.img1{
		.w(100);
		.h(100);
		background: url('http://i.9game.cn/public/web/img/1.f8f43a3e.png');
	}
	.img2{
		.w(60);
		.h(60);
		background: url('http://i.9game.cn/public/web/img/2.762c0351.png');
	}
	.img3{
		.w(75);
		.h(75);
		background: url('http://i.9game.cn/public/web/img/3.e08249e0.png');
	}
	.img4{
		.w(86);
		.h(86);
		background: url('http://i.9game.cn/public/web/img/4.676bcf3c.png');
	}
	.img5{
		.w(66);
		.h(66);
		background: url('http://i.9game.cn/public/web/img/5.ba3a22e2.png');
	}
	.img6{
		.w(56);
		.h(56);
		background: url('http://i.9game.cn/public/web/img/6.0015770b.png');
	}
	.div1{
		position: absolute;
		.l(133);
		.t(150);
	}
	.div2{
		position: absolute;
		.l(50);
		.t(180);
	}
	.div3{
		position: absolute;
		.r(45);
		.t(100);
	}
	.div4{
		position: absolute;
		.r(40);
		.b(50);
	}
	.div5{
		position: absolute;
		.l(95);
		.t(280);
	}
	.div6{
		position: absolute;
		.l(100);
		.t(80);
	}
	.download{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		#con{
			position: relative;
			.m(44,0,0,0);
			.w(375);
			.h(361.5);
			background: url('http://i.9game.cn/public/web/img/bg.62128d0a.jpg');
			background-size: 100%;
			.font(12);
			color: #bb967c;
			text-align: center;
			
		} 
	}
	.bgimg{
		background-size: cover;
		background-position: 50%;
		
	}
</style>