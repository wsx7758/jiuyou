import Vue from 'vue';
import Router from 'vue-router';
import Home from '../components/pages/Home.vue';
import Shoot from '../components/pages/shoot.vue'
import Role from '../components/pages/Role.vue'
import Detalls from '../components/pages/gamedetails.vue'
import Reg from '../components/pages/Reg.vue'
import Login from '../components/pages/Login.vue'
import Mygame from '../components/pages/Mygame.vue'
import Wechat from '../components/pages/wechat.vue'
import Download from '../components/pages/download.vue'
Vue.use(Router);
export default new Router({
	routes:[
	{
		path:'/',
		name:'Home',
		component:Home
	},
	{
		path:'/download',
		name:'Download',
		component:Download
	},
	{
		path:'/shoot',
		name:'Shoot',
		component:Shoot
	},
	{
		path:'/role',
		name:'Role',
		component:Role
	
	},
	{
		path:'/detalls',
		name:'Detalls',
		component:Detalls
	
	},
	{
		path:'/login',
		name:'Login',
		component:Login
	
	},
	{
		path:'/wechat',
		name:'Wechat',
		component:Wechat
	
	},
	{
		path:'/reg',
		name:'Reg',
		component:Reg
	
	},
	{
		path:'/mygame',
		name:'Mygame',
		component:Mygame
	
	}
	]
})