<template>
  <div id="app">
      <!-- <Home/> -->
      <router-view></router-view>
  </div>
</template>

<script>
import Home from './components/pages/Home.vue'
export default {
  name: 'App',
  components: {
      Home
  }
}
</script>

<style>
#app {

}
</style>
